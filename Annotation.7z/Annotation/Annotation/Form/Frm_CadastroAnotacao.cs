﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data;
using System.Collections;
using Annotation.Class;

namespace Annotation
{
    public partial class Frm_CadastroAnotacao : Form
    {
        string arquivoProblemaBinarioString;
        string arquivoAnaliseBinarioString;
        string arquivoSolucaoBinarioString;

        int clickAnexoProblema = 0;
        int clickAnexoAnalise = 0;
        int clickAnexoSolucao = 0;

        public Frm_CadastroAnotacao()
        {
            InitializeComponent();

            lblModulo.Text = "Modulo";
            lblChamado.Text = "Chamado";
            lblProblema.Text = "Desc. Problema";
            lblAnalise.Text = "Desc. Analise";
            lblSolucao.Text = "Desc. Solução";
            lblTela.Text = "Sigla Tela Afetada";
            lblMensagemErro.Text = "Desc. Msg erro";
            ckHouveDemanda.Text = "Problema resolvido com demanda";
            lblDemandaSolucao.Text = "Demanda";
        }

        private void novoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtAnalise.Enabled = true;
            txtChamado.Enabled = true;
            txtMensagemErro.Enabled = true;
            txtProblema.Enabled = true;
            txtSolucao.Enabled = true;
            txtTela.Enabled = true;
            cmbModulo.Enabled = true;
            ckHouveDemanda.Enabled = true;
            btnAnexoAnalise.Enabled = true;
            btnAnexoProblema.Enabled = true;
            btnAnexoSolucao.Enabled = true;
        }

        private void btnAnexoProblema_Click(object sender, EventArgs e)
        {
            clickAnexoProblema = 1;
            AdicionaAnexo();
        }
        private void btnAnexoAnalise_Click(object sender, EventArgs e)
        {
            clickAnexoAnalise = 1;
            AdicionaAnexo();
        }

        private void btnAnexoSolucao_Click(object sender, EventArgs e)
        {
            clickAnexoSolucao = 1;
            AdicionaAnexo();
        }

        private void salvarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DadosAnotacao.Unit dadosAnotacao = new DadosAnotacao.Unit();
            try
            {
                if (cmbModulo.SelectedIndex != -1)
                {
                    dadosAnotacao = InsereDadosClasse();
                    dadosAnotacao.ValidaClasseAnotacao();
                    dadosAnotacao.ValidaClasse();
                    string vJson = DadosAnotacao.SerializedClassUnit(dadosAnotacao);
                    string subDiretorio = dadosAnotacao.Modulo;
                    Fichario fichario = new Fichario("C:\\Users\\douglaslois-mtz\\Desktop\\Arquivos\\Fichario\\" + subDiretorio);
                    

                    if (fichario.status)
                    {
                        fichario.Incluir(dadosAnotacao.Chamado, vJson);
                        if (fichario.status)
                        {
                            MessageBox.Show("OK: " + fichario.mensagem, "Sistema de anotações", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LimpaFormulario();
                        }
                        else
                        {
                            MessageBox.Show("ERR: " + fichario.mensagem, "Sistema de anotações", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("ERR: " + fichario.mensagem, "Sistema de anotações", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Anotações", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        DadosAnotacao.Unit InsereDadosClasse()
        {
            DadosAnotacao.Unit dadosAnotacao = new DadosAnotacao.Unit();

            if(ckHouveDemanda.Checked == true)
            {
                dadosAnotacao.HouveDemandaSolucao = "Sim";
            }
            else
            {
                dadosAnotacao.HouveDemandaSolucao = "Não";
            }

            dadosAnotacao.Modulo  = cmbModulo.Text;
            dadosAnotacao.Chamado = txtChamado.Text;
            dadosAnotacao.MensagemErro = txtMensagemErro.Text;
            dadosAnotacao.Problema  = txtProblema.Text;
            dadosAnotacao.SiglaTela = txtTela.Text;
            dadosAnotacao.Analise = txtAnalise.Text;
            dadosAnotacao.Solucao = txtSolucao.Text;
            
            dadosAnotacao.DemandaSolucao = txtDemandaSolucao.Text;
            
            dadosAnotacao.AnexoProblema = arquivoProblemaBinarioString;
            dadosAnotacao.AnexoAnalise = arquivoAnaliseBinarioString;
            dadosAnotacao.AnexoSolucao = arquivoSolucaoBinarioString;

            return dadosAnotacao;
        }

        private void LimpaFormulario()
        {
            cmbModulo.Text = "";
            txtChamado.Text = "";
            txtMensagemErro.Text = "";
            txtProblema.Text = "";
            txtTela.Text = "";
            txtAnalise.Text = "";
            txtSolucao.Text = "";
            ckHouveDemanda.Checked = false;
            txtDemandaSolucao.Text = "";
        }

        private void ckHouveDemanda_CheckedChanged(object sender, EventArgs e)
        {
            if (ckHouveDemanda.Checked)
            {
                txtDemandaSolucao.Enabled = true;
            }
            else
            {
                txtDemandaSolucao.Enabled = false;
            }
        }
        
        private void AdicionaAnexo()
        {
            DadosAnotacao.Unit dadosAnotacao = new DadosAnotacao.Unit();

            openFileDialog1.InitialDirectory = "C//Temp";
            openFileDialog1.Title = "Selecione o arquivo";
            openFileDialog1.Filter = "Select Valid Document(*.pdf; *.doc; *.xlsx; *.html; *.PNG; *.jpg)|*.pdf; *.docx; *.xlsx; *.html;*.PNG; *.jpg";
            openFileDialog1.FilterIndex = 1;
            try
            {
                if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    if (openFileDialog1.CheckFileExists)
                    {
                        if(clickAnexoProblema == 1)
                        {
                            string path = System.IO.Path.GetFullPath(openFileDialog1.FileName);
                            byte[] arquivoProblemaBinario = File.ReadAllBytes(path);
                            arquivoProblemaBinarioString = Convert.ToBase64String(arquivoProblemaBinario);
                        }
                        if (clickAnexoAnalise == 1)
                        {
                            string path = System.IO.Path.GetFullPath(openFileDialog1.FileName);
                            byte[] arquivoAnaliseBinario = File.ReadAllBytes(path);
                            arquivoAnaliseBinarioString = Convert.ToBase64String(arquivoAnaliseBinario);
                        }
                        if (clickAnexoSolucao == 1)
                        {
                            string path = System.IO.Path.GetFullPath(openFileDialog1.FileName);
                            byte[] arquivoSolucaoBinario = File.ReadAllBytes(path);
                            arquivoSolucaoBinarioString = Convert.ToBase64String(arquivoSolucaoBinario);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void personalizarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_ConsultaAnotacao frm_Consulta = new Frm_ConsultaAnotacao();
            frm_Consulta.ShowDialog();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
