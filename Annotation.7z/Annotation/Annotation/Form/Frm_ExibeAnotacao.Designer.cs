﻿namespace Annotation
{
    partial class Frm_ExibeAnotacao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.arquivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.novoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.abrirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.salvarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salvarcomoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.imprimirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.visualizarImpressãoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.desfazerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refazerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.recortarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copiarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.colarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.selecionarTudoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ferramentasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.personalizarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.opçõesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ajudaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.conteúdoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.índiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pesquisarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.sobreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblModulo = new System.Windows.Forms.Label();
            this.lblChamado = new System.Windows.Forms.Label();
            this.txtChamado = new System.Windows.Forms.TextBox();
            this.txtProblema = new System.Windows.Forms.TextBox();
            this.txtAnalise = new System.Windows.Forms.TextBox();
            this.txtSolucao = new System.Windows.Forms.TextBox();
            this.grpAnotacao = new System.Windows.Forms.GroupBox();
            this.txtDemandaSolucao = new System.Windows.Forms.TextBox();
            this.lblDemandaSolucao = new System.Windows.Forms.Label();
            this.ckHouveDemanda = new System.Windows.Forms.CheckBox();
            this.btnAnexoSolucao = new System.Windows.Forms.Button();
            this.btnAnexoAnalise = new System.Windows.Forms.Button();
            this.btnAnexoProblema = new System.Windows.Forms.Button();
            this.lblMensagemErro = new System.Windows.Forms.Label();
            this.txtMensagemErro = new System.Windows.Forms.TextBox();
            this.lblTela = new System.Windows.Forms.Label();
            this.txtTela = new System.Windows.Forms.TextBox();
            this.cmbModulo = new System.Windows.Forms.ComboBox();
            this.lblSolucao = new System.Windows.Forms.Label();
            this.lblAnalise = new System.Windows.Forms.Label();
            this.lblProblema = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.menuStrip1.SuspendLayout();
            this.grpAnotacao.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.arquivoToolStripMenuItem,
            this.editarToolStripMenuItem,
            this.ferramentasToolStripMenuItem,
            this.ajudaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1121, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // arquivoToolStripMenuItem
            // 
            this.arquivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.novoToolStripMenuItem,
            this.abrirToolStripMenuItem,
            this.toolStripSeparator,
            this.salvarToolStripMenuItem,
            this.salvarcomoToolStripMenuItem,
            this.toolStripSeparator1,
            this.imprimirToolStripMenuItem,
            this.visualizarImpressãoToolStripMenuItem,
            this.toolStripSeparator2,
            this.sairToolStripMenuItem});
            this.arquivoToolStripMenuItem.Name = "arquivoToolStripMenuItem";
            this.arquivoToolStripMenuItem.Size = new System.Drawing.Size(87, 29);
            this.arquivoToolStripMenuItem.Text = "&Arquivo";
            // 
            // novoToolStripMenuItem
            // 
            this.novoToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.novoToolStripMenuItem.Name = "novoToolStripMenuItem";
            this.novoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.novoToolStripMenuItem.Size = new System.Drawing.Size(257, 30);
            this.novoToolStripMenuItem.Text = "&Novo";
            // 
            // abrirToolStripMenuItem
            // 
            this.abrirToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.abrirToolStripMenuItem.Name = "abrirToolStripMenuItem";
            this.abrirToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.abrirToolStripMenuItem.Size = new System.Drawing.Size(257, 30);
            this.abrirToolStripMenuItem.Text = "&Abrir";
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(254, 6);
            // 
            // salvarToolStripMenuItem
            // 
            this.salvarToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.salvarToolStripMenuItem.Name = "salvarToolStripMenuItem";
            this.salvarToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.salvarToolStripMenuItem.Size = new System.Drawing.Size(257, 30);
            this.salvarToolStripMenuItem.Text = "&Salvar";
            // 
            // salvarcomoToolStripMenuItem
            // 
            this.salvarcomoToolStripMenuItem.Name = "salvarcomoToolStripMenuItem";
            this.salvarcomoToolStripMenuItem.Size = new System.Drawing.Size(257, 30);
            this.salvarcomoToolStripMenuItem.Text = "Salvar &como";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(254, 6);
            // 
            // imprimirToolStripMenuItem
            // 
            this.imprimirToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.imprimirToolStripMenuItem.Name = "imprimirToolStripMenuItem";
            this.imprimirToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.imprimirToolStripMenuItem.Size = new System.Drawing.Size(257, 30);
            this.imprimirToolStripMenuItem.Text = "&Imprimir";
            // 
            // visualizarImpressãoToolStripMenuItem
            // 
            this.visualizarImpressãoToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.visualizarImpressãoToolStripMenuItem.Name = "visualizarImpressãoToolStripMenuItem";
            this.visualizarImpressãoToolStripMenuItem.Size = new System.Drawing.Size(257, 30);
            this.visualizarImpressãoToolStripMenuItem.Text = "Visuali&zar Impressão";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(254, 6);
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(257, 30);
            this.sairToolStripMenuItem.Text = "Sai&r";
            // 
            // editarToolStripMenuItem
            // 
            this.editarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.desfazerToolStripMenuItem,
            this.refazerToolStripMenuItem,
            this.toolStripSeparator3,
            this.recortarToolStripMenuItem,
            this.copiarToolStripMenuItem,
            this.colarToolStripMenuItem,
            this.toolStripSeparator4,
            this.selecionarTudoToolStripMenuItem});
            this.editarToolStripMenuItem.Name = "editarToolStripMenuItem";
            this.editarToolStripMenuItem.Size = new System.Drawing.Size(69, 29);
            this.editarToolStripMenuItem.Text = "&Editar";
            // 
            // desfazerToolStripMenuItem
            // 
            this.desfazerToolStripMenuItem.Name = "desfazerToolStripMenuItem";
            this.desfazerToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.desfazerToolStripMenuItem.Size = new System.Drawing.Size(225, 30);
            this.desfazerToolStripMenuItem.Text = "&Desfazer";
            // 
            // refazerToolStripMenuItem
            // 
            this.refazerToolStripMenuItem.Name = "refazerToolStripMenuItem";
            this.refazerToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Y)));
            this.refazerToolStripMenuItem.Size = new System.Drawing.Size(225, 30);
            this.refazerToolStripMenuItem.Text = "&Refazer";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(222, 6);
            // 
            // recortarToolStripMenuItem
            // 
            this.recortarToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.recortarToolStripMenuItem.Name = "recortarToolStripMenuItem";
            this.recortarToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.recortarToolStripMenuItem.Size = new System.Drawing.Size(225, 30);
            this.recortarToolStripMenuItem.Text = "Recor&tar";
            // 
            // copiarToolStripMenuItem
            // 
            this.copiarToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.copiarToolStripMenuItem.Name = "copiarToolStripMenuItem";
            this.copiarToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.copiarToolStripMenuItem.Size = new System.Drawing.Size(225, 30);
            this.copiarToolStripMenuItem.Text = "&Copiar";
            // 
            // colarToolStripMenuItem
            // 
            this.colarToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.colarToolStripMenuItem.Name = "colarToolStripMenuItem";
            this.colarToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.colarToolStripMenuItem.Size = new System.Drawing.Size(225, 30);
            this.colarToolStripMenuItem.Text = "C&olar";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(222, 6);
            // 
            // selecionarTudoToolStripMenuItem
            // 
            this.selecionarTudoToolStripMenuItem.Name = "selecionarTudoToolStripMenuItem";
            this.selecionarTudoToolStripMenuItem.Size = new System.Drawing.Size(225, 30);
            this.selecionarTudoToolStripMenuItem.Text = "Selecionar &Tudo";
            // 
            // ferramentasToolStripMenuItem
            // 
            this.ferramentasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.personalizarToolStripMenuItem,
            this.opçõesToolStripMenuItem});
            this.ferramentasToolStripMenuItem.Name = "ferramentasToolStripMenuItem";
            this.ferramentasToolStripMenuItem.Size = new System.Drawing.Size(121, 29);
            this.ferramentasToolStripMenuItem.Text = "Ferra&mentas";
            // 
            // personalizarToolStripMenuItem
            // 
            this.personalizarToolStripMenuItem.Name = "personalizarToolStripMenuItem";
            this.personalizarToolStripMenuItem.Size = new System.Drawing.Size(252, 30);
            this.personalizarToolStripMenuItem.Text = "&Personalizar";
            // 
            // opçõesToolStripMenuItem
            // 
            this.opçõesToolStripMenuItem.Name = "opçõesToolStripMenuItem";
            this.opçõesToolStripMenuItem.Size = new System.Drawing.Size(252, 30);
            this.opçõesToolStripMenuItem.Text = "&Opções";
            // 
            // ajudaToolStripMenuItem
            // 
            this.ajudaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.conteúdoToolStripMenuItem,
            this.índiceToolStripMenuItem,
            this.pesquisarToolStripMenuItem,
            this.toolStripSeparator5,
            this.sobreToolStripMenuItem});
            this.ajudaToolStripMenuItem.Name = "ajudaToolStripMenuItem";
            this.ajudaToolStripMenuItem.Size = new System.Drawing.Size(70, 29);
            this.ajudaToolStripMenuItem.Text = "Aj&uda";
            // 
            // conteúdoToolStripMenuItem
            // 
            this.conteúdoToolStripMenuItem.Name = "conteúdoToolStripMenuItem";
            this.conteúdoToolStripMenuItem.Size = new System.Drawing.Size(175, 30);
            this.conteúdoToolStripMenuItem.Text = "&Conteúdo";
            // 
            // índiceToolStripMenuItem
            // 
            this.índiceToolStripMenuItem.Name = "índiceToolStripMenuItem";
            this.índiceToolStripMenuItem.Size = new System.Drawing.Size(175, 30);
            this.índiceToolStripMenuItem.Text = "Í&ndice";
            // 
            // pesquisarToolStripMenuItem
            // 
            this.pesquisarToolStripMenuItem.Name = "pesquisarToolStripMenuItem";
            this.pesquisarToolStripMenuItem.Size = new System.Drawing.Size(175, 30);
            this.pesquisarToolStripMenuItem.Text = "&Pesquisar";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(172, 6);
            // 
            // sobreToolStripMenuItem
            // 
            this.sobreToolStripMenuItem.Name = "sobreToolStripMenuItem";
            this.sobreToolStripMenuItem.Size = new System.Drawing.Size(175, 30);
            this.sobreToolStripMenuItem.Text = "&Sobre...";
            // 
            // lblModulo
            // 
            this.lblModulo.AutoSize = true;
            this.lblModulo.Location = new System.Drawing.Point(21, 82);
            this.lblModulo.Name = "lblModulo";
            this.lblModulo.Size = new System.Drawing.Size(51, 20);
            this.lblModulo.TabIndex = 1;
            this.lblModulo.Text = "label1";
            // 
            // lblChamado
            // 
            this.lblChamado.AutoSize = true;
            this.lblChamado.Location = new System.Drawing.Point(21, 25);
            this.lblChamado.Name = "lblChamado";
            this.lblChamado.Size = new System.Drawing.Size(51, 20);
            this.lblChamado.TabIndex = 2;
            this.lblChamado.Text = "label2";
            // 
            // txtChamado
            // 
            this.txtChamado.Enabled = false;
            this.txtChamado.Location = new System.Drawing.Point(151, 25);
            this.txtChamado.Name = "txtChamado";
            this.txtChamado.Size = new System.Drawing.Size(133, 26);
            this.txtChamado.TabIndex = 8;
            // 
            // txtProblema
            // 
            this.txtProblema.Enabled = false;
            this.txtProblema.Location = new System.Drawing.Point(151, 139);
            this.txtProblema.Multiline = true;
            this.txtProblema.Name = "txtProblema";
            this.txtProblema.Size = new System.Drawing.Size(823, 126);
            this.txtProblema.TabIndex = 9;
            // 
            // txtAnalise
            // 
            this.txtAnalise.Enabled = false;
            this.txtAnalise.Location = new System.Drawing.Point(151, 289);
            this.txtAnalise.Multiline = true;
            this.txtAnalise.Name = "txtAnalise";
            this.txtAnalise.Size = new System.Drawing.Size(823, 126);
            this.txtAnalise.TabIndex = 10;
            // 
            // txtSolucao
            // 
            this.txtSolucao.Enabled = false;
            this.txtSolucao.Location = new System.Drawing.Point(151, 451);
            this.txtSolucao.Multiline = true;
            this.txtSolucao.Name = "txtSolucao";
            this.txtSolucao.Size = new System.Drawing.Size(823, 126);
            this.txtSolucao.TabIndex = 11;
            // 
            // grpAnotacao
            // 
            this.grpAnotacao.Controls.Add(this.txtDemandaSolucao);
            this.grpAnotacao.Controls.Add(this.lblDemandaSolucao);
            this.grpAnotacao.Controls.Add(this.ckHouveDemanda);
            this.grpAnotacao.Controls.Add(this.btnAnexoSolucao);
            this.grpAnotacao.Controls.Add(this.btnAnexoAnalise);
            this.grpAnotacao.Controls.Add(this.btnAnexoProblema);
            this.grpAnotacao.Controls.Add(this.lblMensagemErro);
            this.grpAnotacao.Controls.Add(this.txtMensagemErro);
            this.grpAnotacao.Controls.Add(this.lblTela);
            this.grpAnotacao.Controls.Add(this.txtTela);
            this.grpAnotacao.Controls.Add(this.cmbModulo);
            this.grpAnotacao.Controls.Add(this.lblSolucao);
            this.grpAnotacao.Controls.Add(this.lblAnalise);
            this.grpAnotacao.Controls.Add(this.lblProblema);
            this.grpAnotacao.Controls.Add(this.txtProblema);
            this.grpAnotacao.Controls.Add(this.txtSolucao);
            this.grpAnotacao.Controls.Add(this.lblChamado);
            this.grpAnotacao.Controls.Add(this.txtAnalise);
            this.grpAnotacao.Controls.Add(this.lblModulo);
            this.grpAnotacao.Controls.Add(this.txtChamado);
            this.grpAnotacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpAnotacao.Location = new System.Drawing.Point(12, 46);
            this.grpAnotacao.Name = "grpAnotacao";
            this.grpAnotacao.Size = new System.Drawing.Size(1081, 826);
            this.grpAnotacao.TabIndex = 12;
            this.grpAnotacao.TabStop = false;
            // 
            // txtDemandaSolucao
            // 
            this.txtDemandaSolucao.Enabled = false;
            this.txtDemandaSolucao.Location = new System.Drawing.Point(838, 596);
            this.txtDemandaSolucao.Name = "txtDemandaSolucao";
            this.txtDemandaSolucao.Size = new System.Drawing.Size(136, 26);
            this.txtDemandaSolucao.TabIndex = 28;
            // 
            // lblDemandaSolucao
            // 
            this.lblDemandaSolucao.AutoSize = true;
            this.lblDemandaSolucao.Location = new System.Drawing.Point(744, 600);
            this.lblDemandaSolucao.Name = "lblDemandaSolucao";
            this.lblDemandaSolucao.Size = new System.Drawing.Size(51, 20);
            this.lblDemandaSolucao.TabIndex = 27;
            this.lblDemandaSolucao.Text = "label5";
            // 
            // ckHouveDemanda
            // 
            this.ckHouveDemanda.AutoSize = true;
            this.ckHouveDemanda.Enabled = false;
            this.ckHouveDemanda.Location = new System.Drawing.Point(151, 596);
            this.ckHouveDemanda.Name = "ckHouveDemanda";
            this.ckHouveDemanda.Size = new System.Drawing.Size(113, 24);
            this.ckHouveDemanda.TabIndex = 26;
            this.ckHouveDemanda.Text = "checkBox1";
            this.ckHouveDemanda.UseVisualStyleBackColor = true;
            // 
            // btnAnexoSolucao
            // 
            this.btnAnexoSolucao.Enabled = false;
            this.btnAnexoSolucao.Location = new System.Drawing.Point(980, 454);
            this.btnAnexoSolucao.Name = "btnAnexoSolucao";
            this.btnAnexoSolucao.Size = new System.Drawing.Size(75, 33);
            this.btnAnexoSolucao.TabIndex = 24;
            this.btnAnexoSolucao.Text = "button3";
            this.btnAnexoSolucao.UseVisualStyleBackColor = true;
            // 
            // btnAnexoAnalise
            // 
            this.btnAnexoAnalise.Enabled = false;
            this.btnAnexoAnalise.Location = new System.Drawing.Point(980, 292);
            this.btnAnexoAnalise.Name = "btnAnexoAnalise";
            this.btnAnexoAnalise.Size = new System.Drawing.Size(75, 33);
            this.btnAnexoAnalise.TabIndex = 23;
            this.btnAnexoAnalise.Text = "button2";
            this.btnAnexoAnalise.UseVisualStyleBackColor = true;
            // 
            // btnAnexoProblema
            // 
            this.btnAnexoProblema.Enabled = false;
            this.btnAnexoProblema.Location = new System.Drawing.Point(980, 139);
            this.btnAnexoProblema.Name = "btnAnexoProblema";
            this.btnAnexoProblema.Size = new System.Drawing.Size(75, 33);
            this.btnAnexoProblema.TabIndex = 22;
            this.btnAnexoProblema.Text = "button1";
            this.btnAnexoProblema.UseVisualStyleBackColor = true;
            // 
            // lblMensagemErro
            // 
            this.lblMensagemErro.AutoSize = true;
            this.lblMensagemErro.Location = new System.Drawing.Point(21, 686);
            this.lblMensagemErro.Name = "lblMensagemErro";
            this.lblMensagemErro.Size = new System.Drawing.Size(51, 20);
            this.lblMensagemErro.TabIndex = 21;
            this.lblMensagemErro.Text = "label5";
            // 
            // txtMensagemErro
            // 
            this.txtMensagemErro.Enabled = false;
            this.txtMensagemErro.Location = new System.Drawing.Point(151, 683);
            this.txtMensagemErro.Multiline = true;
            this.txtMensagemErro.Name = "txtMensagemErro";
            this.txtMensagemErro.Size = new System.Drawing.Size(823, 126);
            this.txtMensagemErro.TabIndex = 20;
            // 
            // lblTela
            // 
            this.lblTela.AutoSize = true;
            this.lblTela.Location = new System.Drawing.Point(645, 87);
            this.lblTela.Name = "lblTela";
            this.lblTela.Size = new System.Drawing.Size(51, 20);
            this.lblTela.TabIndex = 19;
            this.lblTela.Text = "label6";
            // 
            // txtTela
            // 
            this.txtTela.Enabled = false;
            this.txtTela.Location = new System.Drawing.Point(792, 84);
            this.txtTela.Name = "txtTela";
            this.txtTela.Size = new System.Drawing.Size(182, 26);
            this.txtTela.TabIndex = 18;
            // 
            // cmbModulo
            // 
            this.cmbModulo.Enabled = false;
            this.cmbModulo.FormattingEnabled = true;
            this.cmbModulo.Items.AddRange(new object[] {
            "ADM",
            "COM",
            "IND"});
            this.cmbModulo.Location = new System.Drawing.Point(151, 79);
            this.cmbModulo.Name = "cmbModulo";
            this.cmbModulo.Size = new System.Drawing.Size(133, 28);
            this.cmbModulo.TabIndex = 1;
            // 
            // lblSolucao
            // 
            this.lblSolucao.AutoSize = true;
            this.lblSolucao.Location = new System.Drawing.Point(21, 454);
            this.lblSolucao.Name = "lblSolucao";
            this.lblSolucao.Size = new System.Drawing.Size(51, 20);
            this.lblSolucao.TabIndex = 14;
            this.lblSolucao.Text = "label5";
            // 
            // lblAnalise
            // 
            this.lblAnalise.AutoSize = true;
            this.lblAnalise.Location = new System.Drawing.Point(21, 292);
            this.lblAnalise.Name = "lblAnalise";
            this.lblAnalise.Size = new System.Drawing.Size(51, 20);
            this.lblAnalise.TabIndex = 13;
            this.lblAnalise.Text = "label4";
            // 
            // lblProblema
            // 
            this.lblProblema.AutoSize = true;
            this.lblProblema.Location = new System.Drawing.Point(21, 139);
            this.lblProblema.Name = "lblProblema";
            this.lblProblema.Size = new System.Drawing.Size(51, 20);
            this.lblProblema.TabIndex = 12;
            this.lblProblema.Text = "label3";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Frm_ExibeAnotacao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1121, 884);
            this.Controls.Add(this.grpAnotacao);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Frm_ExibeAnotacao";
            this.Text = "Cadastro Anotação";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.grpAnotacao.ResumeLayout(false);
            this.grpAnotacao.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem arquivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem novoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem abrirToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.ToolStripMenuItem salvarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salvarcomoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem imprimirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem visualizarImpressãoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem desfazerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem refazerToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem recortarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copiarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem colarToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem selecionarTudoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ferramentasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem personalizarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem opçõesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ajudaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem conteúdoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem índiceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pesquisarToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem sobreToolStripMenuItem;
        private System.Windows.Forms.Label lblModulo;
        private System.Windows.Forms.Label lblChamado;
        private System.Windows.Forms.TextBox txtChamado;
        private System.Windows.Forms.TextBox txtProblema;
        private System.Windows.Forms.TextBox txtAnalise;
        private System.Windows.Forms.TextBox txtSolucao;
        private System.Windows.Forms.GroupBox grpAnotacao;
        private System.Windows.Forms.Label lblSolucao;
        private System.Windows.Forms.Label lblAnalise;
        private System.Windows.Forms.Label lblProblema;
        private System.Windows.Forms.ComboBox cmbModulo;
        private System.Windows.Forms.Label lblTela;
        private System.Windows.Forms.TextBox txtTela;
        private System.Windows.Forms.Label lblMensagemErro;
        private System.Windows.Forms.TextBox txtMensagemErro;
        private System.Windows.Forms.Button btnAnexoSolucao;
        private System.Windows.Forms.Button btnAnexoAnalise;
        private System.Windows.Forms.Button btnAnexoProblema;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TextBox txtDemandaSolucao;
        private System.Windows.Forms.Label lblDemandaSolucao;
        private System.Windows.Forms.CheckBox ckHouveDemanda;
    }
}