﻿namespace Annotation
{
    partial class Frm_ConsultaAnotacao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtConsultaAnotacao = new System.Windows.Forms.DataGridView();
            this.cmbModulo = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dtConsultaAnotacao)).BeginInit();
            this.SuspendLayout();
            // 
            // dtConsultaAnotacao
            // 
            this.dtConsultaAnotacao.AllowUserToAddRows = false;
            this.dtConsultaAnotacao.AllowUserToDeleteRows = false;
            this.dtConsultaAnotacao.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtConsultaAnotacao.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            this.dtConsultaAnotacao.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.dtConsultaAnotacao.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtConsultaAnotacao.Location = new System.Drawing.Point(12, 327);
            this.dtConsultaAnotacao.Name = "dtConsultaAnotacao";
            this.dtConsultaAnotacao.ReadOnly = true;
            this.dtConsultaAnotacao.RowTemplate.Height = 28;
            this.dtConsultaAnotacao.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtConsultaAnotacao.Size = new System.Drawing.Size(1355, 275);
            this.dtConsultaAnotacao.TabIndex = 0;
            this.dtConsultaAnotacao.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtConsultaAnotacao_CellDoubleClick);
            // 
            // cmbModulo
            // 
            this.cmbModulo.FormattingEnabled = true;
            this.cmbModulo.Items.AddRange(new object[] {
            "ADM",
            "COM",
            "IND",
            "TODOS"});
            this.cmbModulo.Location = new System.Drawing.Point(12, 65);
            this.cmbModulo.Name = "cmbModulo";
            this.cmbModulo.Size = new System.Drawing.Size(166, 28);
            this.cmbModulo.TabIndex = 1;
            this.cmbModulo.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Frm_ConsultaAnotacao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1379, 614);
            this.Controls.Add(this.cmbModulo);
            this.Controls.Add(this.dtConsultaAnotacao);
            this.Name = "Frm_ConsultaAnotacao";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Frm_ConsultaAnotacao";
            ((System.ComponentModel.ISupportInitialize)(this.dtConsultaAnotacao)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dtConsultaAnotacao;
        private System.Windows.Forms.ComboBox cmbModulo;
    }
}