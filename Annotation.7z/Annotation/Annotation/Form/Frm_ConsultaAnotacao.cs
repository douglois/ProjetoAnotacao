﻿using Annotation.Class;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Annotation
{
    public partial class Frm_ConsultaAnotacao : Form
    {
        string moduloDiretorio = "";
        public Frm_ConsultaAnotacao()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            moduloDiretorio = cmbModulo.Text;
            
            dtConsultaAnotacao.DataSource = dataTable();
        }

        public DataTable dataTable()
        {
            DadosAnotacao.Unit jSon;
            DadosAnotacao.Unit dadosUnit = new DadosAnotacao.Unit();
            List<string> List = new List<string>();
            DataTable newTable = new DataTable();

            if (cmbModulo.Text != "TODOS")
            {
                moduloDiretorio = cmbModulo.Text;
            }
            else
            {
                moduloDiretorio = "";
            }
            Fichario fichario = new Fichario("C:\\Users\\douglaslois-mtz\\Desktop\\Arquivos\\Fichario\\" + moduloDiretorio);

            newTable.Columns.Add("Chamado", typeof(string));
            newTable.Columns.Add("Tela", typeof(string));
            newTable.Columns.Add("Módulo", typeof(string));
            newTable.Columns.Add("Houve Demanda", typeof(string));
            newTable.Columns.Add("Demanda", typeof(string));
            newTable.Columns.Add("Desc Problema", typeof(string));
            newTable.Columns.Add("Mensagem Erro", typeof(string));

            List = fichario.BuscarTodos();

            if (fichario.status = true && List.Count >= 1)
            {
                for (int i = 0; i < List.Count; i++)
                {
                    jSon = DadosAnotacao.DesSerializedClassUnit(List[i]);
                    newTable.Rows.Add(jSon.Chamado, jSon.SiglaTela, jSon.Modulo, jSon.HouveDemandaSolucao, jSon.DemandaSolucao,jSon.Problema,jSon.MensagemErro);
                }
            }
            else
            {
                MessageBox.Show("ERRO: " + fichario.mensagem, "Sistema de anotação", MessageBoxButtons.OK);
            }
            return newTable;
        }

        private void dtConsultaAnotacao_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            var row = dtConsultaAnotacao.Rows[e.RowIndex].Index;
            string conteudoChamado = dtConsultaAnotacao.Rows[e.RowIndex].Cells[0].Value.ToString();
            string conteudoModulo  = dtConsultaAnotacao.Rows[e.RowIndex].Cells[2].Value.ToString();

            Fichario fichario = new Fichario("C:\\Users\\douglaslois-mtz\\Desktop\\Arquivos\\Fichario\\" + conteudoModulo);

            string anotacao = fichario.Buscar(conteudoChamado);

            DadosAnotacao.Unit dadosAnotacao = new DadosAnotacao.Unit();

            dadosAnotacao = DadosAnotacao.DesSerializedClassUnit(anotacao);
        }
    }
}

