﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;


namespace Annotation.Class
{
    public class DadosAnotacao
    {
        public class Unit
        {

            [Required(ErrorMessage = "Necessário selecionar o módulo.")]
            public string Modulo { get; set; }

            [RegularExpression("([0-9]+)", ErrorMessage = "Chamado aceita apenas valores numéricos.")]
            [StringLength(11, MinimumLength = 11, ErrorMessage = "Código do chamado deve ter 11 dígitos.")]
            public string Chamado { get; set; }

            [Required(ErrorMessage = "Necessário descrever sobre o problema.")]
            public string Problema { get; set; }

            [Required(ErrorMessage = "Necessário descrever sobre a analise.")]
            public string Analise { get; set; }

            [Required(ErrorMessage = "Necessário descrever sobre a solução.")]
            public string Solucao { get; set; }

            public string MensagemErro { get; set; }

            [StringLength(8, MinimumLength = 8, ErrorMessage = "Sigla da tela deve ter 8 dígitos.")]
            public string SiglaTela { get; set; }

            public string HouveDemandaSolucao { get; set; }
            public string DemandaSolucao { get; set; }
            public object AnexoProblema { get; set; }
            public object AnexoAnalise { get; set; }
            public object AnexoSolucao { get; set; }

            public void ValidaClasseAnotacao()
            {
                if (this.Problema == this.Analise || this.Analise == this.Solucao)
                {
                    throw new Exception("Analise e problema ou analise e solução, nao podem ser iguais. Descreva corretamente o problema, analise e solução.");
                }
                if(this.HouveDemandaSolucao == "Sim" && this.DemandaSolucao == "")
                {
                    throw new Exception("Favor inserir a demanda solução, caso contrario, remova a flag do campo 'Problema resolvido com demanda'.");

                }
            }

            public void ValidaClasse()
            {
                ValidationContext context = new ValidationContext(this, serviceProvider: null, items: null);
                List<ValidationResult> results = new List<ValidationResult>();
                bool isValid = Validator.TryValidateObject(this, context, results, true);

                if (isValid == false)
                {
                    StringBuilder sbrErrors = new StringBuilder();
                    foreach (var validationResult in results)
                    {
                        sbrErrors.AppendLine(validationResult.ErrorMessage);
                    }
                    throw new ValidationException(sbrErrors.ToString());
                }
            }

            public void IncluirFichario(string Diretorio)
            {
                string clienteJson = DadosAnotacao.SerializedClassUnit(this);
                Fichario F = new Fichario(Diretorio);
                if (F.status)
                {
                    F.Incluir(this.Chamado, clienteJson);
                    if (!(F.status))
                    {
                        throw new Exception(F.mensagem);
                    }
                }
                else
                {
                    throw new Exception(F.mensagem);
                }
            }
        }

        public class List
        {
            public List<Unit> ListUnit { get; set; }
        }

        public static string SerializedClassUnit(Unit unit)
        {
            return JsonConvert.SerializeObject(unit);
        }

        public static Unit DesSerializedClassUnit(string vJson)
        {
            return JsonConvert.DeserializeObject<Unit>(vJson);
        }
    }
}
