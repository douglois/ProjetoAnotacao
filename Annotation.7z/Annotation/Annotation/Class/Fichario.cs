﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Annotation.Class
{
    public class Fichario
    {
        public string diretorio;
        public string mensagem;
        public bool status;

        public Fichario (string Diretorio)
        {
            status = true;
            try
            {
                if (!(Directory.Exists(Diretorio)))
                {
                Directory.CreateDirectory(Diretorio);
                }   
                diretorio = Diretorio;
                mensagem = "Conexao com o diretorio criado com sucesso.";
            }
            catch (Exception ex)
            {
                status = false;
                mensagem = "Conexão com o Fichario com erro: " + ex.Message;
            }
        }

        public void Incluir(string chamado, string jsonUnit)
        {
            status = true;

            try
            {
                if(File.Exists(diretorio + "//" + chamado + ".json"))
                {
                    status = false;
                    mensagem = "Inclusao nao realizada, pois o ID já existe " + chamado;
                }
                else
                {
                    File.WriteAllText(diretorio + "//" + chamado + ".json", jsonUnit);
                    status = true;
                    mensagem = "Inclusao realizada com sucesso";
                }
            }
            catch (Exception ex)
            {
                status = false;
                mensagem = "Erro ao realizar a inclusao no diretorio";
            }
        }

        public void Excluir(string chamado, string jsonUnit)
        {
            try
            {
                if (!(File.Exists(diretorio + "//" + chamado + ".json")))
                {
                    status = false;
                    mensagem = "Erro na exclusao, id inexistente " + chamado;
                }
                else
                {
                    File.Delete(diretorio + "//" + chamado + ".json");
                    status = true;
                    mensagem = "Exclusao realizada com sucesso";
                }
            }
            catch (Exception ex)
            {
                status = false;
                mensagem = "Erro ao realizar a exclusao no diretorio";
            }
        }

        public string Buscar(string chamado)
        {
            status = true;

            try
            {
                if(!(File.Exists(diretorio + "//" + chamado + ".json")))
                {
                    status = false;
                    mensagem = "Erro ao exibir anotação, chamado inexistente.";
                }
                else
                {
                    var arquivo = File.ReadAllText(diretorio + "//" + chamado + ".json");
                    status = true;
                    return arquivo;
                }
            }
            catch (Exception ex)
            {
                status = false;
                mensagem = "Erro ao exibir anotação, chamado inexistente."+ ex.Message;
            }
            return "";
        }

        public List<string> BuscarTodos()
        {
            status = true;
            List<string> List = new List<string>();
            try
            {
                if(diretorio == "C:\\Users\\douglaslois-mtz\\Desktop\\Arquivos\\Fichario\\")
                {
                    var ArquivosTodos = Directory.GetFiles(diretorio, "*.json", SearchOption.AllDirectories);

                    if(ArquivosTodos.Length >= 1)
                    {
                        for (int i = 0; i <= ArquivosTodos.Length - 1; i++)
                        {
                            string conteudo = File.ReadAllText(ArquivosTodos[i]);
                            List.Add(conteudo);
                        }
                    }
                    else
                    {
                        status = false;
                        mensagem = "Não existem arquivos para consulta: ";
                    }
                }
                else
                {
                    var Arquivos = Directory.GetFiles(diretorio, "*.json");

                    if (Arquivos.Length >= 1)
                    {
                        for (int i = 0; i <= Arquivos.Length - 1; i++)
                        {
                            string conteudo = File.ReadAllText(Arquivos[i]);
                            List.Add(conteudo);
                        }
                    }
                    else
                    {
                        status = false;
                        throw new Exception("Não existem arquivos para consulta");
                        //mensagem = "Não existem arquivos para consulta: ";
                    }
                }
                return List;
            }
            catch (Exception ex)
            {
                status = false;
                mensagem = "Erro ao buscar o conteúdo do identificador: " + ex.Message;
            }
            return List;
        }
    }
}
